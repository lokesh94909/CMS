package com.lokesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContractmanagementCmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContractmanagementCmsApplication.class, args);
	}

}
